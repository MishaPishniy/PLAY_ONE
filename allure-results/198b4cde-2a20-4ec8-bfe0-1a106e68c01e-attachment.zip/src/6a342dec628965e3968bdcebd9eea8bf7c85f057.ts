import { test, expect } from '@playwright/test';

test.only('has title', async ({ page }) => {
  await page.goto('/');

const button = page.getByRole('button', {name: 'Login'})
const username = page.getByPlaceholder('Username')
const password = page.getByPlaceholder('Password')
const passsword2 = page.locator('input[type="password"]')
const username2 = page.locator('#login-button')

await page.getByPlaceholder('Username').press('Enter');

await username.fill('standard_user')
await password.fill('secret_sauce');
await button.click()

//await page.getByRole('checkbox').check();
//await page.getByRole('checkbox').uncheck();

await expect(page).toHaveURL(/inventory/);
await expect(page).toHaveTitle(/Swag Labs/);
await expect(page.getByText('Products')).toBeVisible();
await expect( page.locator('.title') ).toHaveText('Products');
await expect( page.locator('.inventory_item') ).toContainText('Backpack');
await expect( page.locator('.inventory_item') ).toHaveCount(6)
await expect( page.getByRole('button', { name: 'Login' }) ).toBeEnabled();
//await expect( page.getByRole('button', { name: 'Login' }) ).toHaveCSS('.button')

await page.locator('[data-test="product-sort-container"]').selectOption('lohi')
await page.getByText('Sauce Labs Backpack').hover();


});